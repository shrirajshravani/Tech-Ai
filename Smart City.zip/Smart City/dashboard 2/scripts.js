// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    // Set the current date and time
    function updateDateTime() {
        const now = new Date();
        const datetime = now.toLocaleString();
        document.getElementById('datetime').innerText = datetime;
    }
    setInterval(updateDateTime, 1000);
    updateDateTime();

    // Create the energy consumption chart
    const ctxEnergy = document.getElementById('energyChart').getContext('2d');
    const energyChart = new Chart(ctxEnergy, {
        type: 'bar',
        data: {
            labels: ['6:30', '7:30', '8:30', '9:30', '10:30', '11:30', '12:30'],
            datasets: [{
                label: 'Energy Consumption (kWh)',
                data: [5, 10, 15, 20, 25, 30, 35],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });

    // Create the parking occupancy chart
    const ctxParking = document.getElementById('parkingChart').getContext('2d');
    const parkingChart = new Chart(ctxParking, {
        type: 'doughnut',
        data: {
            labels: ['Available', 'Occupied', 'Non compliant'],
            datasets: [{
                data: [45, 37, 18],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(255, 206, 86, 0.2)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        }
    });

    // Create the environmental data pie chart
    const ctxEnvironmental = document.getElementById('environmentalChart').getContext('2d');
    const environmentalChart = new Chart(ctxEnvironmental, {
        type: 'pie',
        data: {
            labels: ['Temperature', 'Noise', 'Humidity', 'Light', 'Air Quality', 'Pressure'],
            datasets: [{
                data: [19.6, 60.0, 47.5, 1947.9, 70.0, 67.1],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 206, 86, 0.5)',
                    'rgba(75, 192, 192, 0.5)',
                    'rgba(153, 102, 255, 0.5)',
                    'rgba(255, 159, 64, 0.5)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                position: 'right',
            }
        }
    });
});
