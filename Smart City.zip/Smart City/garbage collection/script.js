document.addEventListener('DOMContentLoaded', function () {
    const garbageData = [
        { id: 1, driverName: 'Ravi Kumar', areaName: 'Shaniwar Peth', garbageArea: 'Area A', timing: '6:00 AM - 7:00 AM', phoneNumber: '+91 1234567890' },
        { id: 2, driverName: 'Sneha Patel', areaName: 'Kumatha Naka', garbageArea: 'Area B', timing: '8:00 AM - 9:00 AM', phoneNumber: '+91 2345678901' },
        { id: 3, driverName: 'Deepak Sharma', areaName: 'Gandhi Nagar', garbageArea: 'Area C', timing: '10:00 AM - 11:00 AM', phoneNumber: '+91 3456789012' },
        { id: 4, driverName: 'Priya Singh', areaName: 'Murarji Peth', garbageArea: 'Area D', timing: '9:00 AM - 10:00 AM', phoneNumber: '+91 4567890123' },
        { id: 5, driverName: 'Amit Deshmukh', areaName: 'Sambhaji Nagar', garbageArea: 'Area E', timing: '7:30 AM - 8:30 AM', phoneNumber: '+91 5678901234' },
        { id: 6, driverName: 'Anjali Pawar', areaName: 'Tuljapur Road', garbageArea: 'Area F', timing: '8:30 AM - 9:30 AM', phoneNumber: '+91 6789012345' },
        { id: 7, driverName: 'Sanjay Patil', areaName: 'Siddheshwar Peth', garbageArea: 'Area G', timing: '11:30 AM - 12:30 PM', phoneNumber: '+91 7890123456' },
        { id: 8, driverName: 'Kavita Mane', areaName: 'Balives', garbageArea: 'Area H', timing: '10:30 AM - 11:30 AM', phoneNumber: '+91 8901234567' },
        { id: 9, driverName: 'Vijay Gaikwad', areaName: 'Saibaba Nagar', garbageArea: 'Area I', timing: '12:00 PM - 1:00 PM', phoneNumber: '+91 9012345678' },
        { id: 10, driverName: 'Pooja More', areaName: 'Kumbharpura', garbageArea: 'Area J', timing: '1:30 PM - 2:30 PM', phoneNumber: '+91 0123456789' },
        { id: 11, driverName: 'Prakash Salunkhe', areaName: 'Raviwar Peth', garbageArea: 'Area K', timing: '2:00 PM - 3:00 PM', phoneNumber: '+91 9876543210' },
        { id: 12, driverName: 'Manisha Joshi', areaName: 'Akkalkot Road', garbageArea: 'Area L', timing: '3:30 PM - 4:30 PM', phoneNumber: '+91 8765432109' },
        { id: 13, driverName: 'Rajesh Khatri', areaName: 'Chati Galli', garbageArea: 'Area M', timing: '4:00 PM - 5:00 PM', phoneNumber: '+91 7654321098' },
        { id: 14, driverName: 'Anita Gupta', areaName: 'Vijapur Road', garbageArea: 'Area N', timing: '5:30 PM - 6:30 PM', phoneNumber: '+91 6543210987' },
        { id: 15, driverName: 'Sunil Jain', areaName: 'Budhwar Peth', garbageArea: 'Area O', timing: '6:30 PM - 7:30 PM', phoneNumber: '+91 5432109876' },
        { id: 16, driverName: 'Mangesh Pawar', areaName: 'Vakhar Bhag', garbageArea: 'Area P', timing: '7:00 AM - 8:00 AM', phoneNumber: '+91 4321098765' },
        { id: 17, driverName: 'Rohini Desai', areaName: 'Solapur Bazaar', garbageArea: 'Area Q', timing: '8:30 AM - 9:30 AM', phoneNumber: '+91 3210987654' },
        { id: 18, driverName: 'Nitin Shah', areaName: 'Kalewadi', garbageArea: 'Area R', timing: '9:30 AM - 10:30 AM', phoneNumber: '+91 2109876543' },
        { id: 19, driverName: 'Ankita Patel', areaName: 'Rahul Nagar', garbageArea: 'Area S', timing: '10:30 AM - 11:30 AM', phoneNumber: '+91 1098765432' },
        { id: 20, driverName: 'Pradeep Singh', areaName: 'Ganj Peth', garbageArea: 'Area T', timing: '11:30 AM - 12:30 PM', phoneNumber: '+91 0987654321' }
    ];

    const tableBody = document.querySelector('#garbage-table tbody');
    const editModal = document.getElementById('editModal');
    const editForm = document.getElementById('editForm');

    // Function to display data in the table
    function displayDataInTable(data) {
        tableBody.innerHTML = '';
        data.forEach(truck => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${truck.id}</td>
                <td>${truck.driverName}</td>
                <td>${truck.areaName}</td>
                <td>${truck.garbageArea}</td>
                <td>${truck.timing}</td>
                <td>${truck.phoneNumber}</td>
                <td>
                    <button class="edit-btn" data-id="${truck.id}">Edit</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Initial display of data
    displayDataInTable(garbageData);

    // Function to open edit modal
    function openEditModal(truckId) {
        const truck = garbageData.find(item => item.id === truckId);
        if (truck) {
            document.getElementById('driverName').value = truck.driverName;
            document.getElementById('areaName').value = truck.areaName;
            document.getElementById('garbageArea').value = truck.garbageArea;
            document.getElementById('timing').value = truck.timing;
            document.getElementById('phoneNumber').value = truck.phoneNumber;
            editModal.style.display = 'block';
        }
    }

    // Event listener for edit buttons
    tableBody.addEventListener('click', function(event) {
        if (event.target.classList.contains('edit-btn')) {
            const truckId = parseInt(event.target.getAttribute('data-id'));
            openEditModal(truckId);
        }
    });

    // Event listener for close button in modal
    document.querySelector('.close').addEventListener('click', function() {
        editModal.style.display = 'none';
    });

    // Event listener for saving changes in modal
    document.getElementById('saveChanges').addEventListener('click', function() {
        // Update truck data in garbageData array
        const truckId = parseInt(document.querySelector('.edit-btn[data-id]').getAttribute('data-id'));
        const updatedTruck = {
            id: truckId,
            driverName: document.getElementById('driverName').value,
            areaName: document.getElementById('areaName').value,
            garbageArea: document.getElementById('garbageArea').value,
            timing: document.getElementById('timing').value,
            phoneNumber: document.getElementById('phoneNumber').value
        };
        const index = garbageData.findIndex(item => item.id === truckId);
        if (index !== -1) {
            garbageData[index] = updatedTruck;
            displayDataInTable(garbageData);
            editModal.style.display = 'none';
        }
    });

    // Function to filter table rows based on input
    function filterTable() {
        const searchInput = document.getElementById('searchInput').value.toLowerCase();
        const filteredData = garbageData.filter(truck =>
            truck.id.toString().includes(searchInput) ||
            truck.driverName.toLowerCase().includes(searchInput) ||
            truck.areaName.toLowerCase().includes(searchInput) ||
            truck.garbageArea.toLowerCase().includes(searchInput) ||
            truck.timing.toLowerCase().includes(searchInput) ||
            truck.phoneNumber.includes(searchInput)
        );
        displayDataInTable(filteredData);
    }

    // Event listener for input in search field
    document.getElementById('searchInput').addEventListener('input', filterTable);
});
