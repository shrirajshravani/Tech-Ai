document.addEventListener('DOMContentLoaded', () => {
    const map = L.map('map').setView([17.6599, 75.9064], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    const environmentData = [
        { id: 1, area: 'Navipeth', location: [17.6599, 75.9064], airQuality: 'Good', temperature: '30°C', humidity: '40%', uvRadiation: 'Low' },
        { id: 2, area: 'Murarji Peth', location: [17.6615, 75.9082], airQuality: 'Moderate', temperature: '32°C', humidity: '45%', uvRadiation: 'Moderate' },
        { id: 3, area: 'Sidheshwar Peth', location: [17.6575, 75.9042], airQuality: 'Poor', temperature: '35°C', humidity: '50%', uvRadiation: 'High' },
        { id: 4, area: 'Akkalkot Road', location: [17.6500, 75.9250], airQuality: 'Good', temperature: '28°C', humidity: '35%', uvRadiation: 'Low' },
        { id: 5, area: 'Sakhar Peth', location: [17.6710, 75.9061], airQuality: 'Moderate', temperature: '33°C', humidity: '48%', uvRadiation: 'Moderate' },
        { id: 6, area: 'Jule Solapur', location: [17.6671, 75.9205], airQuality: 'Poor', temperature: '34°C', humidity: '52%', uvRadiation: 'High' },
        { id: 7, area: 'Bhavani Peth', location: [17.6762, 75.9081], airQuality: 'Good', temperature: '29°C', humidity: '38%', uvRadiation: 'Low' },
        { id: 8, area: 'Pune Naka', location: [17.6837, 75.9011], airQuality: 'Moderate', temperature: '31°C', humidity: '42%', uvRadiation: 'Moderate' },
        { id: 9, area: 'Railway Lines', location: [17.6856, 75.9092], airQuality: 'Poor', temperature: '36°C', humidity: '55%', uvRadiation: 'High' },
        { id: 10, area: 'Sambhaji Chowk', location: [17.6565, 75.9085], airQuality: 'Good', temperature: '27°C', humidity: '33%', uvRadiation: 'Low' },
        { id: 11, area: 'Laxmi Nagar', location: [17.6678, 75.9091], airQuality: 'Moderate', temperature: '32°C', humidity: '45%', uvRadiation: 'Moderate' },
        { id: 12, area: 'Solapur Bypass', location: [17.6752, 75.9123], airQuality: 'Poor', temperature: '35°C', humidity: '50%', uvRadiation: 'High' },
        { id: 13, area: 'Indira Nagar', location: [17.6660, 75.9243], airQuality: 'Good', temperature: '30°C', humidity: '40%', uvRadiation: 'Low' },
        { id: 14, area: 'Gandhi Nagar', location: [17.6695, 75.9210], airQuality: 'Moderate', temperature: '32°C', humidity: '45%', uvRadiation: 'Moderate' },
        { id: 15, area: 'Mahatma Phule Nagar', location: [17.6702, 75.9228], airQuality: 'Poor', temperature: '35°C', humidity: '50%', uvRadiation: 'High' },
        { id: 16, area: 'Jadhav Nagar', location: [17.6721, 75.9175], airQuality: 'Good', temperature: '28°C', humidity: '35%', uvRadiation: 'Low' },
        { id: 17, area: 'Ram Nagar', location: [17.6725, 75.9152], airQuality: 'Moderate', temperature: '33°C', humidity: '48%', uvRadiation: 'Moderate' },
        { id: 18, area: 'Nehru Nagar', location: [17.6707, 75.9135], airQuality: 'Poor', temperature: '34°C', humidity: '52%', uvRadiation: 'High' },
        { id: 19, area: 'Tilak Nagar', location: [17.6680, 75.9196], airQuality: 'Good', temperature: '29°C', humidity: '38%', uvRadiation: 'Low' },
        { id: 20, area: 'Shivaji Nagar', location: [17.6675, 75.9220], airQuality: 'Moderate', temperature: '31°C', humidity: '42%', uvRadiation: 'Moderate' },
        { id: 21, area: 'Siddheshwar Temple', location: [17.6728, 75.9073], airQuality: 'Poor', temperature: '36°C', humidity: '55%', uvRadiation: 'High' },
        { id: 22, area: 'Tuljapur Road', location: [17.6503, 75.8987], airQuality: 'Good', temperature: '27°C', humidity: '33%', uvRadiation: 'Low' },
        { id: 23, area: 'Vijapur Road', location: [17.6732, 75.9235], airQuality: 'Moderate', temperature: '32°C', humidity: '45%', uvRadiation: 'Moderate' },
        { id: 24, area: 'Ravivar Peth', location: [17.6611, 75.9105], airQuality: 'Poor', temperature: '35°C', humidity: '50%', uvRadiation: 'High' },
        { id: 25, area: 'Ashok Chowk', location: [17.6785, 75.8983], airQuality: 'Good', temperature: '30°C', humidity: '40%', uvRadiation: 'Low' }
    ];

    let mapMarkers = [];

    const getColorByAirQuality = (airQuality) => {
        switch(airQuality) {
            case 'Good':
                return 'green';
            case 'Moderate':
                return 'yellow';
            case 'Poor':
                return 'red';
            default:
                return 'blue';
        }
    };

    const displayEnvironmentData = (data) => {
        mapMarkers.forEach(marker => map.removeLayer(marker));
        mapMarkers = [];

        data.forEach(environment => {
            const circle = L.circle(environment.location, {
                color: getColorByAirQuality(environment.airQuality),
                fillColor: getColorByAirQuality(environment.airQuality),
                fillOpacity: 0.5,
                radius: 300
            }).addTo(map)
            .bindPopup(`<b>Area:</b> ${environment.area}<br><b>Air Quality:</b> ${environment.airQuality}<br><b>Temperature:</b> ${environment.temperature}<br><b>Humidity:</b> ${environment.humidity}<br><b>UV Radiation:</b> ${environment.uvRadiation}`);

            mapMarkers.push(circle);

            circle.on('mouseover', function () {
                this.openPopup();
            });
            circle.on('mouseout', function () {
                this.closePopup();
            });
        });
    };

    const displayEnvironmentTable = (data) => {
        const environmentDataBody = document.getElementById('environment-data');
        environmentDataBody.innerHTML = '';
        data.forEach(environment => {
            const row = document.createElement('tr');
            row.innerHTML = `<td>${environment.area}</td><td>${environment.airQuality}</td><td>${environment.temperature}</td><td>${environment.humidity}</td><td>${environment.uvRadiation}</td>`;
            environmentDataBody.appendChild(row);

            row.addEventListener('click', () => {
                const selectedEnvironment = environmentData.find(item => item.area === environment.area);
                map.setView(selectedEnvironment.location, 15);
                mapMarkers.forEach(marker => {
                    if (marker.getLatLng().equals(selectedEnvironment.location)) {
                        marker.openPopup();
                    }
                });
            });
        });
    };

    displayEnvironmentData(environmentData);
    displayEnvironmentTable(environmentData);

    const searchEnvironment = () => {
        const input = document.getElementById('search-input').value.toLowerCase();
        const filteredData = environmentData.filter(environment => environment.area.toLowerCase().includes(input));
        displayEnvironmentTable(filteredData);

        if (filteredData.length > 0) {
            const selectedEnvironment = filteredData[0];
            map.setView(selectedEnvironment.location, 15);
            mapMarkers.forEach(marker => {
                if (marker.getLatLng().equals(selectedEnvironment.location)) {
                    marker.openPopup();
                }
            });
        }
    };

    setInterval(() => {
        environmentData.forEach(environment => {
            const airQualities = ['Good', 'Moderate', 'Poor'];
            const colors = ['green', 'yellow', 'red'];
            const uvRadiationLevels = ['Low', 'Moderate', 'High'];
            const index = Math.floor(Math.random() * airQualities.length);
            environment.airQuality = airQualities[index];
            environment.color = colors[index];
            environment.uvRadiation = uvRadiationLevels[index];
        });

        displayEnvironmentData(environmentData);

        const searchInput = document.getElementById('search-input').value.toLowerCase();
        if (searchInput.trim() !== '') {
            const filteredData = environmentData.filter(environment => environment.area.toLowerCase().includes(searchInput));
            displayEnvironmentTable(filteredData);
        } else {
            displayEnvironmentTable(environmentData);
        }
    }, 10000);

    const searchInput = document.getElementById('search-input');
    searchInput.addEventListener('input', searchEnvironment);
});
