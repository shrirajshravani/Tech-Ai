document.addEventListener('DOMContentLoaded', () => {
    const map = L.map('map').setView([17.6599, 75.9064], 13);
  
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);
  
    // Mock data for traffic conditions (can be replaced with real-time data)
    let trafficData = [
      // Solapur
      { id: 1, area: 'Navipeth', location: [17.6599, 75.9064], condition: 'Heavy Traffic', color: 'red' },
      { id: 2, area: 'Murarji Peth', location: [17.6615, 75.9082], condition: 'Moderate Traffic', color: 'orange' },
      { id: 3, area: 'Sidheshwar Peth', location: [17.6575, 75.9042], condition: 'Light Traffic', color: 'green' },
      { id: 4, area: 'Akkalkot Road', location: [17.6500, 75.9250], condition: 'Heavy Traffic', color: 'red' },
      { id: 5, area: 'Sakhar Peth', location: [17.6710, 75.9061], condition: 'Moderate Traffic', color: 'orange' },
      { id: 6, area: 'Jule Solapur', location: [17.6671, 75.9205], condition: 'Light Traffic', color: 'green' },
      { id: 7, area: 'Bhavani Peth', location: [17.6762, 75.9081], condition: 'Heavy Traffic', color: 'red' },
      { id: 8, area: 'Pune Naka', location: [17.6837, 75.9011], condition: 'Moderate Traffic', color: 'orange' },
      { id: 9, area: 'Railway Lines', location: [17.6856, 75.9092], condition: 'Light Traffic', color: 'green' },
      { id: 10, area: 'Sambhaji Chowk', location: [17.6565, 75.9085], condition: 'Heavy Traffic', color: 'red' },
      { id: 11, area: 'Laxmi Nagar', location: [17.6678, 75.9091], condition: 'Moderate Traffic', color: 'orange' },
      { id: 12, area: 'Solapur Bypass', location: [17.6752, 75.9123], condition: 'Light Traffic', color: 'green' },
  
      // Jule Solapur
      { id: 13, area: 'Indira Nagar', location: [17.6660, 75.9243], condition: 'Moderate Traffic', color: 'orange' },
      { id: 14, area: 'Gandhi Nagar', location: [17.6695, 75.9210], condition: 'Heavy Traffic', color: 'red' },
      { id: 15, area: 'Mahatma Phule Nagar', location: [17.6702, 75.9228], condition: 'Light Traffic', color: 'green' },
      { id: 16, area: 'Jadhav Nagar', location: [17.6721, 75.9175], condition: 'Heavy Traffic', color: 'red' },
      { id: 17, area: 'Ram Nagar', location: [17.6725, 75.9152], condition: 'Moderate Traffic', color: 'orange' },
      { id: 18, area: 'Nehru Nagar', location: [17.6707, 75.9135], condition: 'Light Traffic', color: 'green' },
      { id: 19, area: 'Tilak Nagar', location: [17.6680, 75.9196], condition: 'Heavy Traffic', color: 'red' },
      { id: 20, area: 'Shivaji Nagar', location: [17.6675, 75.9220], condition: 'Moderate Traffic', color: 'orange' },
  
      // Additional areas
      { id: 21, area: 'Siddheshwar Temple', location: [17.6728, 75.9073], condition: 'Moderate Traffic', color: 'orange' },
      { id: 22, area: 'Tuljapur Road', location: [17.6503, 75.8987], condition: 'Light Traffic', color: 'green' },
      { id: 23, area: 'Vijapur Road', location: [17.6732, 75.9235], condition: 'Heavy Traffic', color: 'red' },
      { id: 24, area: 'Ravivar Peth', location: [17.6611, 75.9105], condition: 'Light Traffic', color: 'green' },
      { id: 25, area: 'Ashok Chowk', location: [17.6785, 75.8983], condition: 'Heavy Traffic', color: 'red' }
    ];
  
    // Array to hold all map markers
    let mapMarkers = [];
  
    // Function to display traffic data on the map
    const displayTrafficData = (data) => {
      // Clear previous markers
      mapMarkers.forEach(marker => map.removeLayer(marker));
      mapMarkers = [];
  
      // Display new markers
      data.forEach(traffic => {
        const circle = L.circle(traffic.location, {
          color: traffic.color,
          fillColor: traffic.color,
          fillOpacity: 0.5, // Adjust transparency here (0 is fully transparent, 1 is fully opaque)
          radius: 300
        }).addTo(map)
          .bindPopup(`<b>Area:</b> ${traffic.area}<br><b>Condition:</b> ${traffic.condition}`);
        
        // Add marker to markers array
        mapMarkers.push(circle);
  
        // Open popup on mouseover and close on mouseout
        circle.on('mouseover', function (e) {
          this.openPopup();
        });
        circle.on('mouseout', function (e) {
          this.closePopup();
        });
      });
    };
  
    // Function to display traffic information in the table
    const displayTrafficTable = (data) => {
      const trafficDataBody = document.getElementById('traffic-data');
      trafficDataBody.innerHTML = ''; // Clear previous data
      data.forEach(traffic => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${traffic.area}</td><td>${traffic.condition}</td>`;
        trafficDataBody.appendChild(row);
  
        // Highlight area on map when clicked on table row
        row.addEventListener('click', () => {
          const selectedTraffic = trafficData.find(item => item.area === traffic.area);
          map.setView(selectedTraffic.location, 15); // Set map view to selected area
          mapMarkers.forEach(marker => {
            if (marker.getLatLng().equals(selectedTraffic.location)) {
              marker.openPopup();
            }
          });
        });
      });
    };
  
    // Display initial traffic data on the map and in the table
    displayTrafficData(trafficData);
    displayTrafficTable(trafficData);
  
    // Function to search traffic information
    const searchTraffic = () => {
      const input = document.getElementById('search-input').value.toLowerCase();
      const filteredData = trafficData.filter(traffic =>
        traffic.area.toLowerCase().includes(input)
      );
      displayTrafficTable(filteredData);
  
      // Highlight searched area on the map
      if (filteredData.length > 0) {
        const selectedTraffic = filteredData[0]; // Assuming only one result for simplicity
        map.setView(selectedTraffic.location, 15); // Set map view to selected area
        mapMarkers.forEach(marker => {
          if (marker.getLatLng().equals(selectedTraffic.location)) {
            marker.openPopup();
          }
        });
      }
    };
  
    // Simulate real-time updates (every 10 seconds)
    setInterval(() => {
      // Randomly update traffic conditions
      trafficData.forEach(traffic => {
        const conditions = ['Heavy Traffic', 'Moderate Traffic', 'Light Traffic'];
        const colors = ['red', 'orange', 'green'];
        const index = Math.floor(Math.random() * conditions.length);
        traffic.condition = conditions[index];
        traffic.color = colors[index];
      });
  
      // Redisplay updated traffic data
      displayTrafficData(trafficData);
  
      // Check if search input is not empty, then filter and display
      const searchInput = document.getElementById('search-input').value.toLowerCase();
      if (searchInput.trim() !== '') {
        const filteredData = trafficData.filter(traffic =>
          traffic.area.toLowerCase().includes(searchInput)
        );
        displayTrafficTable(filteredData);
      } else {
        displayTrafficTable(trafficData);
      }
    }, 10000);
  
    // Enhanced Features:
    // - Implement real-time data integration for accurate updates
    // - Integrate machine learning for predictive analytics and alerts
    // - Enable interactive features like route suggestions and incident reporting
    // - Enhance usability with user-friendly search functionality and interface
  
    // Search functionality setup
    const searchInput = document.getElementById('search-input');
    searchInput.addEventListener('input', searchTraffic);
  });
  