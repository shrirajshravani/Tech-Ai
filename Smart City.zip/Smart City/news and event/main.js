document.addEventListener('DOMContentLoaded', () => {
    const newsData = [
      { id: 1, type: 'function', title: 'Inauguration of New Solar Power Plant', description: 'Solapur inaugurates a new solar power plant aimed at sustainable energy production.', date: '2024-07-01', time: '10:00 AM', location: [17.6599, 75.9064] },
      { id: 2, type: 'event', title: 'Annual Cultural Festival - July 2024', description: 'Join us for the annual cultural festival celebrating diversity and heritage in Solapur.', date: '2024-07-20', time: '09:00 AM', location: [17.6719, 75.9090] },
      { id: 3, type: 'program', title: 'Launch of Smart City Project', description: 'Solapur gears up for the launch of its Smart City project, integrating advanced technologies for urban development.', date: '2024-08-01', time: '11:30 AM', location: [17.6732, 75.9235] },
      { id: 4, type: 'function', title: 'Educational Seminar on Sustainable Agriculture', description: 'A seminar discussing sustainable agricultural practices and their impact on rural communities.', date: '2024-07-05', time: '02:00 PM', location: [17.6675, 75.9180] },
      { id: 5, type: 'news', title: 'New Hospital Opens in Solapur City', description: 'The inauguration of a new state-of-the-art hospital facility to improve healthcare access in Solapur.', date: '2024-07-10', time: '11:00 AM', location: [17.6785, 75.9010] },
      { id: 6, type: 'event', title: 'Tech Expo 2024', description: 'Explore the latest advancements in technology at Solapur\'s Tech Expo 2024, featuring innovative startups and tech giants.', date: '2024-08-15', time: '10:00 AM', location: [17.6610, 75.9060] },
      // Add more news items as needed
    ];
  
    const eventData = [
      { id: 1, type: 'function', title: 'Health Camp at Jule Solapur', description: 'Free health check-up camp organized by Solapur Medical Association.', date: '2024-07-05', time: '08:00 AM', location: [17.6650, 75.9240] },
      { id: 2, type: 'program', title: 'Launch of Water Conservation Initiative', description: 'Solapur launches a new initiative to promote water conservation practices across the city.', date: '2024-07-15', time: '10:30 AM', location: [17.6710, 75.9200] },
      { id: 3, type: 'government', title: 'Town Hall Meeting with Mayor', description: 'Join us for a town hall meeting with Solapur Mayor to discuss civic issues and community feedback.', date: '2024-07-10', time: '02:00 PM', location: [17.6750, 75.9120] },
      { id: 4, type: 'event', title: 'Youth Leadership Conference', description: 'Empowering Solapur\'s youth through leadership skills development and networking opportunities.', date: '2024-07-25', time: '09:30 AM', location: [17.6800, 75.9050] },
      { id: 5, type: 'program', title: 'Startup Pitch Competition', description: 'Pitch your startup idea and win funding at Solapur\'s Startup Pitch Competition 2024.', date: '2024-08-05', time: '11:00 AM', location: [17.6660, 75.9150] },
      { id: 6, type: 'event', title: 'Solapur Marathon 2024', description: 'Join thousands of runners in the annual Solapur Marathon, promoting fitness and community spirit.', date: '2024-09-01', time: '06:00 AM', location: [17.6900, 75.9100] },
      // Add more event items as needed
    ];
  
    const map = L.map('map').setView([17.6599, 75.9064], 13);
  
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);
  
    // Function to display markers on the map
    const displayMarkers = (data, type) => {
      data.forEach(item => {
        const marker = L.marker(item.location).addTo(map)
          .bindPopup(`<b>${item.title}</b><br>Date: ${item.date}<br>Time: ${item.time}<br>${item.description}`);
  
        // Customize marker icon based on type
        if (type === 'news') {
          marker.setIcon(L.icon({
            iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            tooltipAnchor: [16, -28],
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
            shadowSize: [41, 41]
          }));
        } else if (type === 'event') {
          marker.setIcon(L.icon({
            iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            tooltipAnchor: [16, -28],
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
            shadowSize: [41, 41]
          }));
        }
      });
    };
  
    // Function to render news and events in table
    const renderNewsAndEventsTable = (newsData, eventData) => {
      const newsEventsTable = document.getElementById('news-events-table');
      const tableBody = document.getElementById('news-events-data');
      tableBody.innerHTML = '';
  
      // Function to add row to table
      const addRowToTable = (item) => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${item.type}</td><td>${item.title}</td><td>${item.date}</td><td>${item.time}</td><td>${item.description}</td>`;
        tableBody.appendChild(row);
  
        // Highlight marker on map when row clicked
        row.addEventListener('click', () => {
          map.setView(item.location, 15); // Adjust zoom level as needed
          map.eachLayer(layer => {
            if (layer instanceof L.Marker && layer.getLatLng().equals(item.location)) {
              layer.openPopup();
            }
          });
        });
      };
  
      // Add news items to table
      newsData.forEach(item => {
        addRowToTable(item);
      });
  
      // Add event items to table
      eventData.forEach(item => {
        addRowToTable(item);
      });
    };
  
    // Display markers and table on map load
    displayMarkers(newsData, 'news');
    displayMarkers(eventData, 'event');
    renderNewsAndEventsTable(newsData, eventData);
  });
  