document.addEventListener("DOMContentLoaded", function() {
    // Sample schedule data for Solapur city buses with area names, times, bus number, driver name, and driver phone number
    const schedule = {
        "Sangameshwar": {
            busNumber: "MH12AB1234",
            driverName: "Ramesh Kumar",
            driverPhoneNumber: "+91 9876543210",
            area: "Sangameshwar Nagar",
            schedule: {
                "07:00": "Bus Depot",
                "09:00": "Central Station",
                "11:00": "City Center",
                "13:00": "Industrial Area",
                "15:00": "Akashwani Chowk",
                "17:00": "Sangameshwar Nagar"
            }
        },
        "City Bus": {
            busNumber: "MH14CD5678",
            driverName: "Suresh Patel",
            driverPhoneNumber: "+91 8765432109",
            area: "City Center",
            schedule: {
                "06:30": "City Center",
                "08:30": "Akashwani Chowk",
                "10:30": "Bus Depot",
                "12:30": "Industrial Area",
                "14:30": "Sangameshwar Nagar",
                "16:30": "Central Station"
            }
        },
        "Akashwani Bus": {
            busNumber: "MH15EF9101",
            driverName: "Manoj Singh",
            driverPhoneNumber: "+91 7654321098",
            area: "Akashwani Chowk",
            schedule: {
                "07:15": "Akashwani Chowk",
                "09:15": "Sangameshwar Nagar",
                "11:15": "City Center",
                "13:15": "Bus Depot",
                "15:15": "Central Station",
                "17:15": "Industrial Area"
            }
        },
        "Industrial Area Bus": {
            busNumber: "MH16GH2345",
            driverName: "Anil Deshmukh",
            driverPhoneNumber: "+91 9876543211",
            area: "Industrial Area",
            schedule: {
                "06:45": "Industrial Area",
                "08:45": "Sangameshwar Nagar",
                "10:45": "City Center",
                "12:45": "Bus Depot",
                "14:45": "Akashwani Chowk",
                "16:45": "Central Station"
            }
        },
        "Central Station Bus": {
            busNumber: "MH17IJ3456",
            driverName: "Rajesh Gupta",
            driverPhoneNumber: "+91 8765432110",
            area: "Central Station",
            schedule: {
                "07:30": "Central Station",
                "09:30": "Akashwani Chowk",
                "11:30": "Bus Depot",
                "13:30": "Industrial Area",
                "15:30": "Sangameshwar Nagar",
                "17:30": "City Center"
            }
        },
        "Bus Depot Shuttle": {
            busNumber: "MH18KL4567",
            driverName: "Amit Singh",
            driverPhoneNumber: "+91 7654321100",
            area: "Bus Depot",
            schedule: {
                "06:00": "Bus Depot",
                "08:00": "Sangameshwar Nagar",
                "10:00": "City Center",
                "12:00": "Industrial Area",
                "14:00": "Akashwani Chowk",
                "16:00": "Central Station"
            }
        },
        "Gandhi Nagar Express": {
            busNumber: "MH19MN5678",
            driverName: "Sanjay Shah",
            driverPhoneNumber: "+91 9876543222",
            area: "Gandhi Nagar",
            schedule: {
                "07:45": "Gandhi Nagar",
                "09:45": "City Center",
                "11:45": "Bus Depot",
                "13:45": "Industrial Area",
                "15:45": "Akashwani Chowk",
                "17:45": "Sangameshwar Nagar"
            }
        },
        "Raviwar Peth Connection": {
            busNumber: "MH20OP6789",
            driverName: "Vikram Desai",
            driverPhoneNumber: "+91 8765432333",
            area: "Raviwar Peth",
            schedule: {
                "07:30": "Raviwar Peth",
                "09:30": "City Center",
                "11:30": "Bus Depot",
                "13:30": "Industrial Area",
                "15:30": "Akashwani Chowk",
                "17:30": "Sangameshwar Nagar"
            }
        },
        "Mahatma Phule Marg Route": {
            busNumber: "MH21QR7890",
            driverName: "Arun Kumar",
            driverPhoneNumber: "+91 7654323444",
            area: "Mahatma Phule Marg",
            schedule: {
                "06:45": "Mahatma Phule Marg",
                "08:45": "Sangameshwar Nagar",
                "10:45": "City Center",
                "12:45": "Bus Depot",
                "14:45": "Akashwani Chowk",
                "16:45": "Central Station"
            }
        },
        "Vijapur Road Express": {
            busNumber: "MH22ST8901",
            driverName: "Nitin Sharma",
            driverPhoneNumber: "+91 9876543555",
            area: "Vijapur Road",
            schedule: {
                "07:15": "Vijapur Road",
                "09:15": "City Center",
                "11:15": "Bus Depot",
                "13:15": "Industrial Area",
                "15:15": "Akashwani Chowk",
                "17:15": "Sangameshwar Nagar"
            }
        },
        "Shaniwar Peth Connection": {
            busNumber: "MH23UV9012",
            driverName: "Ajay Verma",
            driverPhoneNumber: "+91 8765433666",
            area: "Shaniwar Peth",
            schedule: {
                "07:00": "Shaniwar Peth",
                "09:00": "City Center",
                "11:00": "Bus Depot",
                "13:00": "Industrial Area",
                "15:00": "Akashwani Chowk",
                "17:00": "Sangameshwar Nagar"
            }
        },
        "Balewadi Stadium Connection": {
            busNumber: "MH24WX0123",
            driverName: "Prakash Reddy",
            driverPhoneNumber: "+91 7654323777",
            area: "Balewadi Stadium",
            schedule: {
                "06:30": "Balewadi Stadium",
                "08:30": "Sangameshwar Nagar",
                "10:30": "City Center",
                "12:30": "Bus Depot",
                "14:30": "Akashwani Chowk",
                "16:30": "Central Station"
            }
        },
        "Jawaharlal Nehru Marg Route": {
            busNumber: "MH25YZ1234",
            driverName: "Deepak Jain",
            driverPhoneNumber: "+91 9876543888",
            area: "Jawaharlal Nehru Marg",
            schedule: {
                "07:45": "Jawaharlal Nehru Marg",
                "09:45": "City Center",
                "11:45": "Bus Depot",
                "13:45": "Industrial Area",
                "15:45": "Akashwani Chowk",
                "17:45": "Sangameshwar Nagar"
            }
        },
        // Add more buses with their respective details
    };

    const scheduleContainer = document.getElementById("scheduleContainer");
    const busSearchInput = document.getElementById("busSearch");

    // Function to format time with AM and PM
    function formatTime(time24) {
        let [hours, minutes] = time24.split(':');
        let suffix = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12 || 12; // Convert to 12-hour format
        return `${hours}:${minutes} ${suffix}`;
    }

    // Function to display the schedule based on search
    function displaySchedule(searchTerm = "") {
        scheduleContainer.innerHTML = ""; // Clear existing content

        let srNumber = 1; // Initialize serial number

        for (const bus in schedule) {
            if (schedule.hasOwnProperty(bus)) {
                // Filter buses based on search term
                if (bus.toLowerCase().includes(searchTerm.toLowerCase())) {
                    const { busNumber, driverName, driverPhoneNumber, area, schedule: timings } = schedule[bus];
                    const busScheduleHTML = `
                        <div class="schedule-item">
                            <div class="sr-number">${srNumber}</div>
                            <div class="info">
                                <h3>${bus}</h3>
                                <p><strong>Area:</strong> ${area}</p>
                                <ul>
                                    ${Object.entries(timings).map(([time24, areaName]) => `
                                        <li><strong>${formatTime(time24)}:</strong> ${areaName}</li>
                                    `).join('')}
                                </ul>
                            </div>
                            <div class="details">
                                <p><strong>Bus Number:</strong> ${busNumber}</p>
                                <p><strong>Driver Name:</strong> ${driverName}</p>
                                <p><strong>Driver Phone:</strong> ${driverPhoneNumber}</p>
                            </div>
                        </div>
                    `;
                    scheduleContainer.innerHTML += busScheduleHTML;
                    srNumber++; // Increment serial number
                }
            }
        }

        // Display message if no results found
        if (scheduleContainer.innerHTML === "") {
            scheduleContainer.innerHTML = "<p>No results found.</p>";
        }
    }

    // Event listener for search input
    busSearchInput.addEventListener("input", function() {
        const searchTerm = this.value.trim();
        displaySchedule(searchTerm);
    });

    // Initial display of schedule
    displaySchedule("");
});
