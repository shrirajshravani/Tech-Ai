document.addEventListener('DOMContentLoaded', function () {
    const waterData = [
        { id: 1, area: 'Solapur City', source: 'Bhima River', capacity: '100,000 liters', usage: '70,000 liters', status: 'Normal', supplyTime: 'Morning (6:00 AM - 9:00 AM)', supplierName: 'Rajendra Water Supply', phoneNumber: '9876543210' },
        { id: 2, area: 'Sadashiv Peth', source: 'Nira River', capacity: '80,000 liters', usage: '50,000 liters', status: 'Normal', supplyTime: 'Evening (5:00 PM - 8:00 PM)', supplierName: 'Anjali Water Services', phoneNumber: '8765432109' },
        { id: 3, area: 'Chati Galli', source: 'Groundwater', capacity: '120,000 liters', usage: '90,000 liters', status: 'Critical', supplyTime: 'Afternoon (10:00 AM - 1:00 PM)', supplierName: 'Rahul Water Suppliers', phoneNumber: '7654321098' },
        { id: 4, area: 'Ashok Nagar', source: 'Bhima River', capacity: '90,000 liters', usage: '60,000 liters', status: 'Normal', supplyTime: 'Morning (7:00 AM - 10:00 AM)', supplierName: 'Priya Water Supply', phoneNumber: '6543210987' },
        { id: 5, area: 'Kumatha Naka', source: 'Nira River', capacity: '70,000 liters', usage: '45,000 liters', status: 'Normal', supplyTime: 'Evening (6:30 PM - 9:30 PM)', supplierName: 'Amit Water Services', phoneNumber: '5432109876' },
        { id: 6, area: 'Murarji Peth', source: 'Groundwater', capacity: '110,000 liters', usage: '80,000 liters', status: 'Normal', supplyTime: 'Morning (8:00 AM - 11:00 AM)', supplierName: 'Sunita Water Supply', phoneNumber: '4321098765' },
        { id: 7, area: 'Balewadi', source: 'Bhima River', capacity: '95,000 liters', usage: '55,000 liters', status: 'Normal', supplyTime: 'Afternoon (4:00 PM - 7:00 PM)', supplierName: 'Girish Water Services', phoneNumber: '3210987654' },
        { id: 8, area: 'Shivaji Nagar', source: 'Nira River', capacity: '75,000 liters', usage: '40,000 liters', status: 'Normal', supplyTime: 'Afternoon (3:00 PM - 6:00 PM)', supplierName: 'Swati Water Suppliers', phoneNumber: '2109876543' },
        { id: 9, area: 'Gandhi Chowk', source: 'Groundwater', capacity: '115,000 liters', usage: '85,000 liters', status: 'Critical', supplyTime: 'Afternoon (11:00 AM - 2:00 PM)', supplierName: 'Prakash Water Supply', phoneNumber: '1098765432' },
        { id: 10, area: 'Raviwar Peth', source: 'Bhima River', capacity: '85,000 liters', usage: '65,000 liters', status: 'Normal', supplyTime: 'Morning (7:30 AM - 10:30 AM)', supplierName: 'Neha Water Services', phoneNumber: '0987654321' },
        { id: 11, area: 'Tilak Chowk', source: 'Nira River', capacity: '65,000 liters', usage: '35,000 liters', status: 'Normal', supplyTime: 'Afternoon (2:30 PM - 5:30 PM)', supplierName: 'Arun Water Suppliers', phoneNumber: '8765432101' },
        { id: 12, area: 'Shaniwar Peth', source: 'Groundwater', capacity: '125,000 liters', usage: '95,000 liters', status: 'Critical', supplyTime: 'Afternoon (12:00 PM - 3:00 PM)', supplierName: 'Shilpa Water Supply', phoneNumber: '7654321098' },
        { id: 13, area: 'Vijapur Road', source: 'Bhima River', capacity: '88,000 liters', usage: '58,000 liters', status: 'Normal', supplyTime: 'Morning (7:30 AM - 10:30 AM)', supplierName: 'Vinod Water Services', phoneNumber: '6543210987' },
        { id: 14, area: 'Kumtha Naka', source: 'Nira River', capacity: '70,000 liters', usage: '45,000 liters', status: 'Normal', supplyTime: 'Evening (5:30 PM - 8:30 PM)', supplierName: 'Manisha Water Suppliers', phoneNumber: '5432109876' },
        { id: 15, area: 'Rajarampuri', source: 'Nira River', capacity: '70,000 liters', usage: '45,000 liters', status: 'Normal', supplyTime: 'Evening (5:30 PM - 8:30 PM)', supplierName: 'Ravi Water Supply', phoneNumber: '4321098765' },
        // Add more entries as needed
    ];

    // Function to display water resource data in a table
    function displayWaterData(data) {
        const table = document.createElement('table');
        const tableHeader = `
            <tr>
                <th>Sr. No.</th>
                <th>Area Name</th>
                <th>Water Source</th>
                <th>Capacity (liters)</th>
                <th>Usage (liters)</th>
                <th>Status</th>
                <th>Supply Time</th>
                <th>Supplier Name</th>
                <th>Phone Number</th>
            </tr>
        `;
        table.innerHTML = tableHeader;

        data.forEach((item, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${item.area}</td>
                <td>${item.source}</td>
                <td>${item.capacity}</td>
                <td>${item.usage}</td>
                <td>${item.status}</td>
                <td>${getTimePeriod(item.supplyTime)}</td>
                <td>${item.supplierName}</td>
                <td>${item.phoneNumber}</td>
            `;
            table.appendChild(row);
        });

        const waterDataDiv = document.getElementById('water-data');
        waterDataDiv.innerHTML = '';
        waterDataDiv.appendChild(table);
    }

    // Function to determine time period based on supply time
    function getTimePeriod(supplyTime) {
        const timeRanges = [
            { period: 'Morning', start: 600, end: 900 },
            { period: 'Afternoon', start: 1000, end: 1500 },
            { period: 'Evening', start: 1700, end: 2000 },
            { period: 'Night', start: 2100, end: 2400 }
        ];

        const time = parseTime(supplyTime);

        for (let range of timeRanges) {
            if (time >= range.start && time <= range.end) {
                return `${range.period} (${supplyTime})`;
            }
        }

        return supplyTime; // Default return original supply time if no match
    }

    // Helper function to parse time in HH:MM format to integer
    function parseTime(timeString) {
        const [hours, minutes] = timeString.split(':').map(part => parseInt(part));
        return hours * 100 + minutes;
    }

    // Initial display of water resource data
    displayWaterData(waterData);
});
